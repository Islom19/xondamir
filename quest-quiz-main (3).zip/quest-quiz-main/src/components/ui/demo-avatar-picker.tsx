import { AvatarPicker } from "@/components/ui/avatar-picker"

export function DemoAvatarPicker() {
    return <AvatarPicker />
}
